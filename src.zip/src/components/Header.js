import React from 'react'
import './Header.css';
// import logo from "./src/Assets/logo"



export function Header() {
  return (
    <div>
    <header> 
        {/* <img src={logo} alt='logo' /> */}
        <h1> India Post Visibility System 2.0  </h1>
            
        </header>
    </div>
  )
}
